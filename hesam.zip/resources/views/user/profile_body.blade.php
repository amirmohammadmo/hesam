@extends('user.index')
@section('contend')
    @include('user.layouts.body_profile_form')
@endsection
