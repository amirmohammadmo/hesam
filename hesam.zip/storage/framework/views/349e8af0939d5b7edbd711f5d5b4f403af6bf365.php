<?php $__env->startSection('contend'); ?>
    <?php echo $__env->make('user.layouts.body_profile_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\hesam\resources\views/user/profile_body.blade.php ENDPATH**/ ?>