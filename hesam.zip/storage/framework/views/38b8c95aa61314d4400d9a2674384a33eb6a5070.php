<?php $__env->startSection('contend'); ?>
    <form action="<?php echo e(Route('admin.food.programme.post',$id)); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

    <div class="mb-3">
        <label for="formFile" class="form-label"><?php echo e('ارسال برنامه غذایی'.' '.$user->name); ?></label>
        <input class="form-control" type="file" id="formFile" name="food_programme">
    </div>
        <button type="submit" class="btn btn-primary">ارسال</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\hesam\resources\views/admin/food_send_programm.blade.php ENDPATH**/ ?>