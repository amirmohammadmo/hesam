<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\hesam\resources\views/admin/layouts/success.blade.php ENDPATH**/ ?>