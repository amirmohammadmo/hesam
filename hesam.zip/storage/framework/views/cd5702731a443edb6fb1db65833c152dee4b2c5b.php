<?php $__env->startSection('contend'); ?>
    <?php session(['type'=>'2']) ?>
    <?php echo $__env->make('user.layouts.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\hesam\resources\views/user/Competition_program.blade.php ENDPATH**/ ?>