<?php $__env->startSection('contend'); ?>
    <div class="row mb-5">
        <h5 class="pb-1 mb-4">برنامه ی ورزشی</h5>

        <?php if($train_programms && count($train_programms) > 0 ): ?>
      <?php $__currentLoopData = $train_programms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train_programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4">
            <div class="card text-center mb-3">
                <div class="card-body">
                    <h5 class="card-title">Special title treatment</h5>
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="<?php echo e(asset("train_programme/$train_programm->pdf_name")); ?>" class="btn btn-primary">دانلود برنامه</a>
                </div>
            </div>
        </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php else: ?> <?php echo e('برنماه تمرینی موجود نمی باشد'); ?> <?php endif; ?>
          <div class="row mb-5">
              <h5 class="pb-1 mb-4">برنامه ی غذایی</h5>
              <?php if($food_programms && count($food_programms) > 0 ): ?>
              <?php $__currentLoopData = $food_programms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $food_programm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-6 col-lg-4">
                      <div class="card text-center mb-3">
                          <div class="card-body">
                              <h5 class="card-title">Special title treatment</h5>
                              <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                              <a href="<?php echo e(asset("Food_programme/$food_programm->pdf_name")); ?>" class="btn btn-primary">دانلود برنامه</a>
                          </div>
                      </div>
                  </div> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <?php else: ?> <?php echo e('برنماه غذایی موجود نمی باشد'); ?> <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\hesam\resources\views/admin/programm_show_user.blade.php ENDPATH**/ ?>